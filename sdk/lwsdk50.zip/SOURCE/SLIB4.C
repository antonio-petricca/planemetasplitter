/*
 * LWSDK Library Source File
 * Copyright 1995  NewTek, Inc.
 */
#include <splug.h>

#ifdef _AMIGA
#include <functions.h>

struct ExecBase         *SysBase;
struct DosBase          *DosBase;
#endif
#ifdef __SASC
       extern int  __stdargs    __fpinit (void);
       extern void __stdargs    __fpterm (void);
#endif
#ifdef _AMIGA
	XCALL_(void *)
_Startup (void)
{
	void                    *val;

	XCALL_INIT;

	SysBase = *((struct ExecBase **)4);
	DosBase = (struct DosBase *) OpenLibrary ((UBYTE*) "dos.library", 37L);
	if (!DosBase)
		return NULL;

	#ifdef __SASC
	       if (__fpinit ())
		       goto die;
	#endif

	val = Startup ();
	if (val)
		return val;

die:
	#ifdef __SASC
	       __fpterm ();
	#endif
	CloseLibrary ((struct Library *) DosBase);
	return NULL;
}
	XCALL_(void)
_Shutdown (
	void                    *serverData)
{
	XCALL_INIT;

	Shutdown (serverData);
	#ifdef __SASC
	       __fpterm ();
	#endif
	CloseLibrary ((struct Library *) DosBase);
}
#endif
