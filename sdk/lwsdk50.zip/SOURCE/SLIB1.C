/*
 * LWSDK Library Source File
 * Copyright 1995  NewTek, Inc.
 */
#include <splug.h>
	void *
Startup (void)
{
	return (void *) 4;
}
