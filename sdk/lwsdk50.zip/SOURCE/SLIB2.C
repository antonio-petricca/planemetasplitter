/*
 * LWSDK Library Source File
 * Copyright 1995  NewTek, Inc.
 */
#include <splug.h>
	void
Shutdown (
	void                    *serverData)
{
}
